import sys
from io import StringIO

# --- script.hp を読み込み ---
try:
    with open("script.hp") as f:
        lines = f.read().splitlines()
except FileNotFoundError:
    print("Error: script.hp が見つかりません。")
    sys.exit(1)

if not lines:
    print("Error: script.hp が空です。")
    sys.exit(1)

# --- 最初の行でモード判定 ---
first_line = lines[0].strip()

if first_line == "mode=encodemode":
    mode = "encodemode"
elif first_line == "mode=decodemode":
    mode = "decodemode"
else:
    print("Error: script.hp の最初の行に mode=encodemode または mode=decodemode を書いてください。")
    sys.exit(1)

# --- 残りを script_hp として扱う ---
script_hp = "\n".join(lines[1:]).replace("\n", ",")

# --- HML辞書 ---
hml_letters = {
    "a": "0000000", "b": "0000001", "c": "0000010", "d": "0000011",
    "e": "0000100", "f": "0000101", "g": "0000110", "h": "0000111",
    "i": "0001000", "j": "0001001", "k": "0001010", "l": "0001011",
    "m": "0001100", "n": "0001101", "o": "0001110", "p": "0001111",
    "q": "0010000", "r": "0010001", "s": "0010010", "t": "0010011",
    "u": "0010100", "v": "0010101", "w": "0010110", "x": "0010111",
    "y": "0011000", "z": "0011001",
}

hml_symbols = {
    "!": "0011010", "\"": "0011011", "#": "0011100", "%": "0011101",
    "&": "0011110", "'": "0011111", "(": "0100000", ")": "0100001",
    "*": "0100010", "+": "0100011", ",": "0100100", "-": "0100101",
    ".": "0100110", "/": "0100111", ":": "0101000", "\\": "0101001",
    ";": "0101010", "<": "0101011", "=": "0101100", ">": "0101101",
    "@": "0101110", "[": "0101111", "?": "0110000", "]": "0110001",
    "^": "0110010", "_": "0110011", "{": "0110100", "|": "0110101",
    "}": "0110110", "~": "0110111",
}

hml_numbers = {
    "0": "0111000", "1": "0111001", "2": "0111010", "3": "0111011",
    "4": "0111100", "5": "0111101", "6": "0111110", "7": "0111111",
    "8": "1000000", "9": "1000001",
}

hml_upper = {
    "A": "1000010", "B": "1000011", "C": "1000100", "D": "1000101",
    "E": "1000110", "F": "1000111", "G": "1001000", "H": "1001001",
    "I": "1001010", "J": "1001011", "K": "1001100", "L": "1001101",
    "M": "1001110", "N": "1001111", "O": "1010000", "P": "1010001",
    "Q": "1010010", "R": "1010011", "S": "1010100", "T": "1010101",
    "U": "1010110", "V": "1010111", "W": "1011000", "X": "1011001",
    "Y": "1011010", "Z": "1011011",
}

hml_special = {
    " ": "3",
    "\n": "2",
}

# --- 辞書統合 ---
hml = {}
hml.update(hml_letters)
hml.update(hml_symbols)
hml.update(hml_numbers)
hml.update(hml_special)
hml.update(hml_upper)

decode_hml = {v: k for k, v in hml.items()}

# ============================================================
#                     ENCODE MODE
# ============================================================
if mode == "encodemode":
    text = "\n".join(lines[1:])
    encoded = []

    for ch in text:
        if ch not in hml:
            print(f"Error: 未定義の文字 '{ch}' をエンコードできません。")
            sys.exit(1)
        encoded.append(hml[ch])

    print(",".join(encoded))
    sys.exit(0)

# ============================================================
#                     DECODE MODE
# ============================================================
codes = [c for c in script_hp.split(",") if c != ""]

decoded_chars = []
for c in codes:
    if c not in decode_hml:
        print(f"Error: 未定義のHMLコード {c} が見つかりました。")
        sys.exit(1)
    decoded_chars.append(decode_hml[c])

decoded_text = "".join(decoded_chars)

# --- Pythonコードの実行結果をキャプチャ ---
buffer = StringIO()
sys.stdout = buffer

try:
    exec(decoded_text)
except Exception as e:
    print(f"Error: 実行中に例外が発生しました: {e}")

sys.stdout = sys.__stdout__

print(buffer.getvalue())